$(function() {
  
  let $window = $(window);
  // TEMPO 
  let Tempo = Backbone.Model.extend({
    initialize: function() {      
      this.on('change:playing', this.Play)
      this.on('change:tempo', this.changeTempo)
    },

    // BUTTON PLAY
    Play: function() {
      let _this = this;
      let tempoCounter = function() {
        setTimeout(function() {
          $window.trigger('beat', _this.beat || 0)
          _this.beat++
          if (_this.beat === 16) _this.beat = 0
          if (_this.get('playing')) tempoCounter()
        }, _this.get('bpm'))
      };

      if (this.get('playing')) {
        this.beat = 0;
        tempoCounter()
      }
    },

    // CHANGE TEMPO
    changeTempo: function() {
      this.set('bpm', 60000 / this.get('tempo') / 4)
    }
  })
  
  let DrumModel = Backbone.Model.extend({
    initialize: function() {
      this.set('beats', [])
      this.$audio = $('<audio />')
      
      this.on('change:button1 change:button2 change:useAlt', this.setFile)
      this.on('change:vol', this.setVol)
      this.on('change:beat', this.changeBeat)
      
      $window.on('beat', _.bind(this.onBeat, this))
    },
    setFile: function() {
      let processValue = function(val) {
        let processedValue;
        switch(val) {
          case 0:
            processedValue = '00'
            break;
          case 1:
            processedValue = '25'
            break;
            case 2:
              processedValue = '50'
              break;
            case 3:
              processedValue = '75'
              break;
            case 4:
              processedValue = '10'
              break;
            default:
              processedValue = ''
        }
        return processedValue
      }

      let button1 = processValue(this.get('button1'))
      let button2 = processValue(this.get('button2'))
      let buttonsVal = '' + button1 + button2;
      let whichId = this.get('useAlt') ? 'drumAltId' : 'drumId'
      let fileName = 'https://mecarter.github.io/js808/samples/' + this.get(whichId) + buttonsVal + '.mp3'
      
      this.$audio.attr('src', fileName)
    },

    // CHANGE DRUM
    changeBeat: function(beat) {
      let oldBeats = this.get('beats')
      if ($.inArray(beat, oldBeats) >= 0) {
        this.set('beats', _.without(oldBeats, beat))
      }
      else {
        this.set('beats', oldBeats.concat(beat))
      }
    },

    // VOLUME BUTTON
    setVol: function() {
      this.$audio[0].volume = this.get('vol') / 10
    },

    onBeat: function(e, beat) {
      if ($.inArray(beat, this.get('beats')) >= 0) {
        if (this.$audio[0].readyState)
          this.$audio[0].currentTime = 0
        this.$audio[0].play()
      }
    }
  })
  
  let Drums = Backbone.Collection.extend({
    model: DrumModel
  });
  
  let Drum = Backbone.View.extend({
    events: {
      'change .button1': 'changebutton',
      'change .button2': 'changebutton',
      'change .vol': 'changebutton',
      'click .drum-toggle': 'changeDrum'
    },
    initialize: function() {
      this.$el = $('#' + this.model.get('id'))
      this.$button1 = this.$('.button1')
      this.$button2 = this.$('.button2')
      
      this.model.set('button1', +this.$button1.val())
      this.model.set('button2', +this.$button2.val())
      
      this.listenTo(this.model, 'change:active', this.toggleActive)
    },
    changeDrum: function() {
      this.$el.toggleClass('use-alt')
      this.model.set('useAlt', !this.model.get('useAlt'))
    },
    changebutton: function(e) {
      let $button = $(e.target)
      this.model.set($button.attr('class'), +$button.val())
    },
    toggleActive: function(drumId) {
      this.$el.toggleClass('active')
    },
  })
  
  let DrumMachine = Backbone.View.extend({
    el: $('#drum_sequencer'),
    events: {
      'click #play': 'Play',
      'change #tempo': 'changeTempo',
      'click .drum': 'changeActive',
      'click #sequencer button': 'sequencerPad'
    },
    initialize: function() {
      this.tempo = new Tempo()
      this.drums = new Drums()
      this.$tempo = this.$('#tempo')
      
      this.listenTo(this.drums, 'add', this.newDrum)
      
      this.tempo.set('tempo', +this.$tempo.val())
      this.$('.drum').each(_.bind(this.createDrum, this))
    },
    Play: function(e) {
      $(e.target).closest('#play').toggleClass('playing')
      this.tempo.set('playing', !this.tempo.get('playing'))
    },
    changeTempo: function(e) {
      this.tempo.set('tempo', +$(e.target).val())
    },
    newDrum: function(drum) {
      let view = new Drum({ model: drum })
    },

    // ADD DRUMS
    createDrum: function(k, drum) {
      let fullId = $(drum).attr('id')
      let splitId = fullId.split('_')
      let drumId = splitId[0]
      let drumAltId = splitId[1]
      
      this.drums.add([{
        id: fullId,
        drumId: drumId,
        drumAltId: drumAltId
      }])
    },
    changeActive: function(e) {
      let drumId = $(e.target).closest('.drum').attr('id')
      let oldActiveDrum = this.drums.findWhere({ active: true })
      let newActiveDrum = this.drums.get(drumId)
      
      if (oldActiveDrum)
        oldActiveDrum.set('active', false)
        
      newActiveDrum.set('active', true)
      
      this.$('#sequencer button').each(_.bind(function(i, e) {
        let beatIsActive = $.inArray(i, newActiveDrum.get('beats')) >= 0;
        $(e).toggleClass('active', beatIsActive)
      }, this))
    },

    // PAD SEQUENCER
    sequencerPad: function(e) {
      let $toggle = $(e.target)
      let activeDrum = this.drums.findWhere({ active: true })
      
      if (activeDrum) {
        $toggle.toggleClass('active');
        activeDrum.trigger('change:beat', $toggle.index())
      }
    }
  });
  
  let drumMachine = new DrumMachine()
  
  // RANGE BUTTON
  let SensorButton = function(element) {
    this.$element = $(element)
    this.$rangeInput = this.$element.find('input[type="range"]')
    this.$button = this.$element.find('.setting_button')
    this.minValue = this.$rangeInput.attr('min')
    this.maxValue = this.$rangeInput.attr('max')
    this.init()
  };
  
  SensorButton.prototype = {
    init: function() {
      this.rotatebutton(this.$rangeInput.val())
      this.$rangeInput.on('mousedown', _.bind(this.mousedown, this))
      this.$rangeInput.on('mouseup', this.mouseup)
    },
    
    mousedown: function() {
      let _this = this;
      _this.$rangeInput.on('mousemove', function() {
        _this.rotatebutton(_this.$rangeInput.val())
      })
    },
    mouseup: function() {
      $(this).off('mousemove')
    },
    rotatebutton: function(rotation) {
      let calculatedRotation = (((rotation - this.minValue) / (this.maxValue - this.minValue)) * 270) - 135
      this.$button.css({
        transform: 'rotate(' + calculatedRotation + 'deg)',
        '-webkit-transform': 'rotate(' + calculatedRotation + 'deg)',
        '-moz-transform': 'rotate(' + calculatedRotation + 'deg)',
        '-ms-transform': 'rotate(' + calculatedRotation + 'deg)'
      })
    }
  }
  
  $.fn.SensorButton = function() {
    this.each(function() {
      new SensorButton(this)
    })
  }

  $('.wrapper').SensorButton()
  
})